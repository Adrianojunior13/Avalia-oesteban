using System;

class Program
{
    static void Main()
    {
        
        Console.WriteLine("Digite a primeira data (formato: dd/MM/yyyy):");
        DateTime data1;
        while (!DateTime.TryParse(Console.ReadLine(), out data1))
        {
            Console.WriteLine("Data inválida. Digite novamente no formato dd/MM/yyyy:");
        }

        
        Console.WriteLine("Digite a segunda data (formato: dd/MM/yyyy):");
        DateTime data2;
        while (!DateTime.TryParse(Console.ReadLine(), out data2))
        {
            Console.WriteLine("Data inválida. Digite novamente no formato dd/MM/yyyy:");
        }


        int diferencaDias = Math.Abs((data2 - data1).Days);

       
        Console.WriteLine($"A diferença entre as datas é de {diferencaDias} dia(s).");
    }
}