using System;

class Program
{
    static void Main()
    {
        Console.Write("Digite a idade em dias: ");
        int dias = int.Parse(Console.ReadLine());

        
        int anos = dias / 365;
        dias = dias % 365;
        
        int meses = dias / 30;
        dias = dias % 30;

        
        Console.WriteLine($"{anos} anos, {meses} meses, {dias} dias.");
    }
}